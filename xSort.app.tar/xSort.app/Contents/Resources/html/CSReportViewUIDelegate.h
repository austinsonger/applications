//
//  CSReportViewUIDelegate.h
//  CardSorting
//
//  Created by Miguel Arroz on 06/04/18.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>

@interface CSReportViewUIDelegate : NSObject {

}

@end
